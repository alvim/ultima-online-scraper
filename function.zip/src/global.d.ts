declare module 'html-table-to-json'
declare module 'tabletojson'
declare module 'node-table-to-csv'
declare module 'copy-to-clipboard'